Arquivo zip gerado em: 09/11/2017 18:29:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Árvore de Cobertura Mínima com Kruskal